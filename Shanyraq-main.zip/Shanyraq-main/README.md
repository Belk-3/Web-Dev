# Shanyraq-project
Shanyraq is a modern real estate marketplace where users can easily buy and sell houses, land, and buildings. Built by Syrgabayev Nurislam, Baitursyn Adilkhan, and Myrzabekov Bekzhan, it offers a simple, fast, and transparent way to connect buyers and sellers in one convenient platform.
